<?php namespace App\SupportedApps\ChangeDetectionio;

class ChangeDetectionio extends \App\SupportedApps
{
}
