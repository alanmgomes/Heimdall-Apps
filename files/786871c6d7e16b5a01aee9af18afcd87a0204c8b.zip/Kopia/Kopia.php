<?php namespace App\SupportedApps\Kopia;

class Kopia extends \App\SupportedApps
{
}
