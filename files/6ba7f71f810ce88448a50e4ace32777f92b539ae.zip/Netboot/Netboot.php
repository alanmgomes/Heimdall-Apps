<?php namespace App\SupportedApps\Netboot;

class Netboot extends \App\SupportedApps
{
}
