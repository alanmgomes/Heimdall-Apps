<?php namespace App\SupportedApps\Seafile;

class Seafile extends \App\SupportedApps
{
}
