<?php namespace App\SupportedApps\WLED;

class WLED extends \App\SupportedApps
{
}
