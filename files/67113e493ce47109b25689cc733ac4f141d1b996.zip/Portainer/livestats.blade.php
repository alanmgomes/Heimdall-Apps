<ul class="livestats">
    <li>
        <span class="title">Running</span>
        <strong>{!! $running !!}</strong>
    </li>
    <li>
        <span class="title">Stopped</span>
        <strong>{!! $stopped !!}</strong>
    </li>
</ul>
