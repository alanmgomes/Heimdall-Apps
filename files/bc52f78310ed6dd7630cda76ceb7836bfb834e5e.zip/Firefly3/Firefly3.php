<?php namespace App\SupportedApps\Firefly3;

class Firefly3 extends \App\SupportedApps
{
}
