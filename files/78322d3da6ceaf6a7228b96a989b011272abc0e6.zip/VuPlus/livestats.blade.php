<ul class="livestats">
    <li>
        <span class="title">Channel</span>
        <span><strong>{!! $channel !!}</strong></span>
    </li>
</ul>
