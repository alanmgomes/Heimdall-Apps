<?php namespace App\SupportedApps\DirectAdmin;

class DirectAdmin extends \App\SupportedApps
{
}
