<?php namespace App\SupportedApps\Munin;

class Munin extends \App\SupportedApps
{
}
