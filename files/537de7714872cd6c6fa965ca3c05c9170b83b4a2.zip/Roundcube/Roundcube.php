<?php namespace App\SupportedApps\Roundcube;

class Roundcube extends \App\SupportedApps
{
}
