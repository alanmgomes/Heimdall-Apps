<?php namespace App\SupportedApps\XWiki;

class XWiki extends \App\SupportedApps
{
}
